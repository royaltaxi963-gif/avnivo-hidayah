# AVNIVO HIDAYAH — browser prototype

Static web preview for reviewing the visual direction and intro animation from a phone browser. It is not the final Android app.

## Run locally
Open `index.html` in a modern browser. Sound effects are generated locally with Web Audio and only play after the user enables sound, due to browser autoplay restrictions.

## Deploy on Render
1. Upload these files to a new GitHub repository (the `index.html` file must be at repository root).
2. In Render, choose **New + → Static Site** and connect that repository.
3. Build command: leave empty.
4. Publish directory: `.`
5. Create Static Site.

## Important limitations
The prayer-time service, compass sensor integration, prayer lessons/data, holy-day calendar, and AI answer service are placeholders and are not connected yet. The animation timing is approximately 3.7 seconds in this web preview; we can tune it after checking it on the actual phone. Android implementation and APK build will happen after core features are integrated.
